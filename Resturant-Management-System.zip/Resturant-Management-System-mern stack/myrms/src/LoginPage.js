import React, { useState } from 'react';
import axios from 'axios';
import Navbar from './Navbar'; 
import './LoginPage.css'; 

function LoginPage() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post('http://localhost:5000/api/login', { username, password });
            setMessage(response.data.message);
            if (response.status === 200) {
                // Save login status to localStorage
                localStorage.setItem('isLoggedIn', 'true');
                localStorage.setItem('username', username);
                // Redirect to menu page upon successful login
                window.location.href = '/menu';
            }
        } catch (error) {
            console.error('Error logging in:', error);
            setMessage('Login failed');
        }
    };

    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbar />
            <div className="content">
                <h1>Login</h1>
                <form onSubmit={handleLogin}>
                    <div>
                        <label htmlFor="username">Username:</label>
                        <input 
                            type="text" 
                            id="username" 
                            placeholder="Username" 
                            value={username} 
                            onChange={(e) => setUsername(e.target.value)} 
                            required 
                        />
                    </div>
                    <div>
                        <label htmlFor="password">Password:</label>
                        <input 
                            type="password" 
                            id="password" 
                            placeholder="Password" 
                            value={password} 
                            onChange={(e) => setPassword(e.target.value)} 
                            required 
                        />
                    </div>
                    <button type="submit">Login</button>
                </form>
                {message && <p>{message}</p>}
            </div>
        </div>
    );
}

export default LoginPage;
