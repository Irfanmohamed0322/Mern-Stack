import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
    const isAdminLoggedIn = localStorage.getItem('adminLoggedIn') === 'true';

    const handleAdminLogout = () => {
        localStorage.setItem('adminLoggedIn', 'false');
        window.location.href = '/admin/login';
    };
    return (
        <nav className="navbar">
            <ul>
                {isAdminLoggedIn ? (
                    <>
                        <li><Link to="/admin/dashboard">Admin Dashboard</Link></li>
                        <li><Link to="/admin/orders">View Orders</Link></li>
                        <li><Link to="/admin/delivery-addresses">Delivery Status</Link></li>
                        <li><button onClick={handleAdminLogout}>Admin Logout</button></li>
                    </>
                ) : (
                    null
                )}
            </ul>
        </nav>
    );
}

export default Navbar;
