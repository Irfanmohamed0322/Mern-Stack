import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './AdminDashboardPage.css';
import Navbars from './Navbars';

function AdminDashboardPage() {
    const [customers, setCustomers] = useState([]);
    const [error, setError] = useState('');
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [isAdmin, setIsAdmin] = useState(false);

    useEffect(() => {
        checkAdminLogin();
        fetchCustomers();
    }, []);

    const checkAdminLogin = () => {
        const adminLoggedIn = localStorage.getItem('adminLoggedIn');
        if (adminLoggedIn === 'true') {
            setIsLoggedIn(true);
            setIsAdmin(true);
        } else {
            window.location.href = '/admin/login'; // Redirect to the admin login page
        }
    };

    const handleLogout = () => {
        localStorage.setItem('adminLoggedIn', 'false');
        window.location.href = '/admin/login'; // Redirect to the admin login page
    };

    const fetchCustomers = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/admin/customers');
            setCustomers(response.data);
        } catch (error) {
            setError('Error fetching customers.');
        }
    };

    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbars />
            
            <h1>Admin Dashboard</h1>
            <h2>Customer Details</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            {customers.length > 0 ? (
                <table>
                    <thead>
                        <tr>
                            <th>Customer ID</th>
                            <th>Username</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                    <tbody>
                        {customers.map(customer => (
                            <tr key={customer._id}>
                                <td>{customer._id}</td>
                                <td>{customer.username}</td>
                                <td>{customer.email}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            ) : (
                <p>No customers found.</p>
            )}
        </div>
    );
}

export default AdminDashboardPage;
 
