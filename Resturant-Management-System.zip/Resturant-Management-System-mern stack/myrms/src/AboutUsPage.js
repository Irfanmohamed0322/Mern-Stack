import React from 'react';
import Navbar from './Navbar';
import './AboutUsPage.css'; 

function AboutUsPage() {
    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbar />
            <div className="contents">
                <h1>About Us</h1>
                <p>Welcome to our Restaurant Management System! We are dedicated to providing an exceptional dining experience for our customers.</p>
                <p>Our mission is to offer delicious and high-quality food, excellent customer service, and a comfortable atmosphere for all our guests.</p>
                <p>At our restaurant, we prioritize freshness, taste, and sustainability. Our chefs carefully select the finest ingredients to create mouthwatering dishes that satisfy your cravings.</p>
                <p>Whether you're dining in with family and friends, ordering takeout, or hosting a special event, we strive to exceed your expectations every time.</p>
                <p>Thank you for choosing us. We look forward to serving you!</p>
            </div>
        </div>
    );
}

export default AboutUsPage;
