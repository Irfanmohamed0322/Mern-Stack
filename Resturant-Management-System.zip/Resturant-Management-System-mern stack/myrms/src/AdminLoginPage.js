import React, { useState } from 'react';
import axios from 'axios';
import Navbar from './Navbar';
import './AdminLoginPage.css';

function AdminLoginPage() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleLogin = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post('http://localhost:5000/api/admin/login', {
                username,
                password
            });

            if (response.data.message === 'Login successful') {
                localStorage.setItem('adminLoggedIn', 'true');
                window.location.href = '/admin/dashboard';
            } else {
                setMessage('Login failed. Please check your credentials.');
            }
        } catch (error) {
            setMessage('Login failed. Please try again later.');
        }
    };

    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbar />
            <div className="content">
                <h1>Admin Login</h1>
                {message && <div className="message">{message}</div>}
                <form onSubmit={handleLogin}>
                    <div>
                        <label htmlFor="username">Username:</label>
                        <input 
                            type="text" 
                            id="username" 
                            name="username" 
                            value={username} 
                            onChange={(e) => setUsername(e.target.value)} 
                            required 
                        />
                    </div>
                    <div>
                        <label htmlFor="password">Password:</label>
                        <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            value={password} 
                            onChange={(e) => setPassword(e.target.value)} 
                            required 
                        />
                    </div>
                    <div>
                        <button type="submit">Login</button>
                    </div>
                </form>
            </div>
        </div>
    );
}

export default AdminLoginPage;
