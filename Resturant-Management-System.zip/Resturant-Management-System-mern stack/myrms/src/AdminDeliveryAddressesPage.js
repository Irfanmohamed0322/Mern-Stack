import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbars from './Navbars';

function AdminDeliveryAddresses() {
    const [deliveryAddresses, setDeliveryAddresses] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        fetchDeliveryAddresses();
    }, []);

    const fetchDeliveryAddresses = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/admin/delivery-addresses');
            setDeliveryAddresses(response.data);
        } catch (error) {
            console.error('Error fetching delivery addresses:', error);
            setError('Error fetching delivery addresses.');
        }
    };

    const handleUpdateDeliveryStatus = async (addressId) => {
        try {
            const response = await axios.put(`http://localhost:5000/api/admin/delivery-addresses/${addressId}/update-status`, {
                deliveryStatus: 'delivered'
            });
            if (response.status === 200) {
                const updatedAddresses = deliveryAddresses.map(address =>
                    address._id === addressId ? { ...address, deliveryStatus: 'delivered' } : address
                );
                setDeliveryAddresses(updatedAddresses);
            } else {
                console.error('Failed to update delivery status');
            }
        } catch (error) {
            console.error('Error updating delivery status:', error);
        }
    };

    const getButtonText = (deliveryStatus) => {
        return deliveryStatus === 'pending' ? 'Update Status' : 'Status Updated';
    };

    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbars />
            <h2>Delivery Addresses</h2>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Address</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Zip Code</th>
                        <th>Delivery Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {deliveryAddresses.map(address => (
                        <tr key={address._id}>
                            <td>{address._id}</td>
                            <td>{address.address}</td>
                            <td>{address.city}</td>
                            <td>{address.state}</td>
                            <td>{address.zipCode}</td>
                            <td>{address.deliveryStatus}</td>
                            <td>
                                <button
                                    onClick={() => handleUpdateDeliveryStatus(address._id)}
                                    disabled={address.deliveryStatus === 'delivered'}
                                >
                                    {getButtonText(address.deliveryStatus)}
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default AdminDeliveryAddresses;
