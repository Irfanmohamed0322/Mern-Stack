import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar';
import pizzaImage from './pizza.avif';
import burgerImage from './burger.jpg';
import sandwichImage from './sandwich.jpg';
import './MenuPage.css';

function MenuItemsPage() {
    const navigate = useNavigate();
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    useEffect(() => {
        const userLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
        setIsLoggedIn(userLoggedIn);
    }, []);

    const addToCart = (event, itemName, itemPrice, quantity) => {
        event.preventDefault();
        if (!isLoggedIn) {
            alert('Please login to add items to your cart.');
            navigate('/login');
        } else {
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            const existingItemIndex = cart.findIndex(item => item.name === itemName);

            if (existingItemIndex !== -1) {
                cart[existingItemIndex].quantity += parseInt(quantity);
            } else {
                cart.push({ name: itemName, price: itemPrice, quantity: parseInt(quantity) });
            }

            localStorage.setItem('cart', JSON.stringify(cart));
            alert('Item added to cart: ' + itemName);
            navigate('/cart');
        }
    };

    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbar />
            <div className="menu-container">
                <h2>Menu Management</h2>

                <div className="menu-item">
                    <img src={pizzaImage} alt="Pizza" className="menu-item-image" />
                    <h3>Pizza</h3>
                    <p>Description of the pizza.</p>
                    <p><b>Price: Rs.200</b></p>
                    <form onSubmit={(e) => addToCart(e, 'Pizza', 200, document.getElementById('quantityPizza').value)}>
                        <label htmlFor="quantityPizza">Quantity:</label>
                        <input type="number" id="quantityPizza" name="quantityPizza" min="1" defaultValue="1" />
                        <button type="submit">Add to Cart</button>
                    </form>
                </div>

                <div className="menu-item">
                    <img src={burgerImage} alt="Burger" className="menu-item-image" />
                    <h3>Burger</h3>
                    <p>Description of the burger.</p>
                    <p><b>Price: Rs.350</b></p>
                    <form onSubmit={(e) => addToCart(e, 'Burger', 350, document.getElementById('quantityBurger').value)}>
                        <label htmlFor="quantityBurger">Quantity:</label>
                        <input type="number" id="quantityBurger" name="quantityBurger" min="1" defaultValue="1" />
                        <button type="submit">Add to Cart</button>
                    </form>
                </div>

                <div className="menu-item">
                    <img src={sandwichImage} alt="Sandwich" className="menu-item-image" />
                    <h3>Sandwich</h3>
                    <p>Description of the sandwich.</p>
                    <p><b>Price: Rs.410</b></p>
                    <form onSubmit={(e) => addToCart(e, 'Sandwich', 410, document.getElementById('quantitySandwich').value)}>
                        <label htmlFor="quantitySandwich">Quantity:</label>
                        <input type="number" id="quantitySandwich" name="quantitySandwich" min="1" defaultValue="1" />
                        <button type="submit">Add to Cart</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default MenuItemsPage;

