const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bodyParser = require('body-parser');
const app = express();

app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));

mongoose.connect('mongodb+srv://irfanmohamed03:eReD4G9at9zbSK8Z@cluster0.ghsofqj.mongodb.net/mydatabase?retryWrites=true&w=majority', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.error('MongoDB connection error:', err));

const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});
const User = mongoose.model('User', userSchema);

const orderSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    items: [{ itemId: String, name: String, price: Number, quantity: Number }],
    totalPrice: Number,
    paymentMethod: String,
    orderDate: { type: Date, default: Date.now },
    paymentStatus: { type: String, default: 'pending' }
});
const Order = mongoose.model('Order', orderSchema);

const deliveryAddressSchema = new mongoose.Schema({
    address: { type: String, required: true },
    city: { type: String, required: true },
    state: { type: String, required: true },
    zipCode: { type: String, required: true },
    deliveryStatus: { type: String, default: 'Pending' }
});
const DeliveryAddress = mongoose.model('DeliveryAddress', deliveryAddressSchema);

app.post('/api/add-delivery-address', async (req, res) => {
    try {
        const { address, city, state, zipCode } = req.body;

        if (!address || !city || !state || !zipCode) {
            return res.status(400).json({ message: 'All address fields are required' });
        }

        const newAddress = new DeliveryAddress({ address, city, state, zipCode });
        await newAddress.save();
        res.status(201).json({ message: 'Delivery address saved successfully', address: newAddress });
    } catch (error) {
        console.error('Error saving delivery address:', error);
        res.status(500).json({ message: 'Failed to save delivery address in the database' });
    }
});

app.post('/api/register', async (req, res) => {
    try {
        const { username, email, password } = req.body;
        const existingUser = await User.findOne({ $or: [{ username }, { email }] });
        if (existingUser) {
            return res.status(400).json({ message: 'Username or email already exists' });
        }
        const newUser = new User({ username, email, password });
        await newUser.save();
        res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
        console.error('Error registering user:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.post('/api/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        const user = await User.findOne({ username, password });
        if (!user) {
            return res.status(400).json({ message: 'Username or password is incorrect' });
        }
        res.status(200).json({ message: 'Login successful' });
    } catch (error) {
        console.error('Error logging in:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.post('/api/admin/login', (req, res) => {
    const { username, password } = req.body;
    if (username === 'admin' && password === 'admin') {
        res.status(200).json({ message: 'Login successful' });
    } else {
        res.status(400).json({ message: 'Invalid credentials' });
    }
});

app.get('/api/admin/customers', async (req, res) => {
    try {
        const customers = await User.find();
        res.status(200).json(customers);
    } catch (error) {
        console.error('Error fetching customers:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.get('/api/admin/orders', async (req, res) => {
    try {
        const orders = await Order.find().populate('userId', 'username');
        res.status(200).json(orders);
    } catch (error) {
        console.error('Error fetching orders:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.put('/api/admin/orders/:orderId/approve', async (req, res) => {
    const { orderId } = req.params;
    try {
        const order = await Order.findByIdAndUpdate(orderId, { paymentStatus: 'approved' }, { new: true });
        if (!order) {
            return res.status(404).json({ message: 'Order not found' });
        }
        res.status(200).json({ message: 'Order approved successfully', order });
    } catch (error) {
        console.error('Error approving order:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.put('/api/admin/delivery-addresses/:addressId/update-status', async (req, res) => {
    const { addressId } = req.params;
    const { deliveryStatus } = req.body;

    try {
        const updatedAddress = await DeliveryAddress.findByIdAndUpdate(addressId, { deliveryStatus }, { new: true });
        if (!updatedAddress) {
            return res.status(404).json({ message: 'Delivery address not found' });
        }
        res.status(200).json({ message: 'Delivery status updated successfully', address: updatedAddress });
    } catch (error) {
        console.error('Error updating delivery status:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.post('/process-payment', async (req, res) => {
    try {
        const { userId, items, totalPrice, paymentMethod } = req.body;
        const order = new Order({
            userId,
            items,
            totalPrice,
            paymentMethod,
            paymentStatus: 'pending'
        });
        await order.save();
        res.status(201).send({ message: 'Order placed successfully', order });
    } catch (error) {
        console.error('Error processing payment:', error);
        res.status(500).json({ message: 'Internal server error' });
    }
});

app.get('/api/admin/delivery-addresses', async (req, res) => {
    try {
        const deliveryAddresses = await DeliveryAddress.find();
        res.status(200).json(deliveryAddresses);
    } catch (error) {
        console.error('Error fetching delivery addresses:', error);
        res.status(500).json({ message: 'Failed to fetch delivery addresses' });
    }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
