import React from 'react';
import Navbar from './Navbar';

function OrderPage() {
    return (
        <div>
            <Navbar />
            <div className="content">
                <h1>Order</h1>
                <h2>Place your order here</h2>
                <form onSubmit={handleSubmit}>
                    <label htmlFor="itemName">Item Name:</label>
                    <input type="text" id="itemName" name="itemName" required />
                    <label htmlFor="quantity">Quantity:</label>
                    <input type="number" id="quantity" name="quantity" min="1" required />
                    <button type="submit">Place Order</button>
                </form>
            </div>
        </div>
    );
}

function handleSubmit(event) {
    event.preventDefault();
    const itemName = event.target.itemName.value;
    const quantity = event.target.quantity.value;
    console.log(`Order placed: ${quantity} ${itemName}`);
}

export default OrderPage;
