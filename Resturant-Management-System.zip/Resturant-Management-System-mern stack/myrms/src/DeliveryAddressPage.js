import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar';
import './DeliveryPage.css';

const DeliveryAddress = () => {
    const [address, setAddress] = useState('');
    const [city, setCity] = useState('');
    const [state, setState] = useState('');
    const [zipCode, setZipCode] = useState('');
    const [message, setMessage] = useState('');
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:5000/api/add-delivery-address', {
                address,
                city,
                state,
                zipCode
            });
            setMessage(response.data.message);
            navigate('/payment');
        } catch (error) {
            setMessage('Failed to save delivery address. Please try again.');
            console.error('Error saving delivery address:', error);
        }
    };

    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbar />
            <div className="delivery-container">
                <h2>Delivery Address</h2>
                <form onSubmit={handleSubmit}>
                    <div>
                        <label>Address:</label>
                        <input
                            type="text"
                            value={address}
                            onChange={(e) => setAddress(e.target.value)}
                            required
                        />
                    </div>
                    <div>
                        <label>City:</label>
                        <input
                            type="text"
                            value={city}
                            onChange={(e) => setCity(e.target.value)}
                            required
                        />
                    </div>
                    <div>
                        <label>State:</label>
                        <input
                            type="text"
                            value={state}
                            onChange={(e) => setState(e.target.value)}
                            required
                        />
                    </div>
                    <div>
                        <label>Zip Code:</label>
                        <input
                            type="text"
                            value={zipCode}
                            onChange={(e) => setZipCode(e.target.value)}
                            required
                        />
                    </div>
                    <button type="submit">Save Address</button>
                </form>
                {message && <p>{message}</p>}
            </div>
        </div>
    );
};

export default DeliveryAddress;
