import React, { useState, useEffect } from 'react';
import axios from 'axios';
import Navbars from './Navbars';

function OrdersPage() {
    const [orders, setOrders] = useState([]);
    const [error, setError] = useState('');

    useEffect(() => {
        fetchOrders();
    }, []);

    const fetchOrders = async () => {
        try {
            const response = await axios.get('http://localhost:5000/api/admin/orders');
            setOrders(response.data);
        } catch (error) {
            console.error('Error fetching orders:', error);
            setError('Error fetching orders.');
        }
    };

    const handleApproveOrder = async (orderId) => {
        try {
            const response = await axios.put(`http://localhost:5000/api/admin/orders/${orderId}/approve`);
            if (response.status === 200) {
                const updatedOrders = orders.map(order => {
                    if (order._id === orderId) {
                        return { ...order, paymentStatus: 'approved' };
                    }
                    return order;
                });
                setOrders(updatedOrders);
            } else {
                console.error('Failed to approve order');
            }
        } catch (error) {
            console.error('Error approving order:', error);
        }
    };

    const getButtonText = (paymentStatus) => {
        return 'Approve';
    };

    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbars />
            <h1>All Customer Orders</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Total Price</th>
                        <th>Order Date</th>
                        <th>Payment Mode</th>
                        <th>Payment Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map(order => (
                        <tr key={order._id}>
                            <td>{order._id}</td>
                            <td>₹{order.totalPrice.toFixed(2)}</td>
                            <td>{new Date(order.orderDate).toLocaleString()}</td>
                            <td>{order.paymentMethod}</td>
                            <td>{order.paymentStatus}</td>
                            <td>
                                <button
                                    onClick={() => handleApproveOrder(order._id)}
                                    disabled={order.paymentStatus === 'approved'}
                                >
                                    {getButtonText(order.paymentStatus)}
                                </button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default OrdersPage;
