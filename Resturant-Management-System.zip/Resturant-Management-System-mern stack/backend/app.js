// backend/app.js or index.js

const express = require('express');
const app = express();
const authRoutes = require('./routes/auth');

// Middleware for parsing JSON request bodies
app.use(express.json());

// Mount the auth routes
app.use('/api/auth', authRoutes);

// Other middleware and route handlers...

module.exports = app;
