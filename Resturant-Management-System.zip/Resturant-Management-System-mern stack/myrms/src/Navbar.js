import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const isAdminLoggedIn = localStorage.getItem('adminLoggedIn') === 'true';

    const handleLogout = () => {
        if (isAdminLoggedIn) {
            localStorage.setItem('adminLoggedIn', 'false');
            window.location.href = '/admin/login';
        } else {
            localStorage.setItem('isLoggedIn', 'false');
            localStorage.removeItem('username');
            window.location.href = '/login';
        }
    };

    return (
        <nav className="navbar">
            <ul>
                <li><Link to="/">Home</Link></li>
                {isLoggedIn ? (
                    <>
                        <li><Link to="/menu">Menu</Link></li>
                        <li><Link to="/cart">Cart</Link></li>
                        <li><button onClick={handleLogout}>Logout</button></li>
                    </>
                ) : (
                    <>
                        <li><Link to="/login">Login</Link></li>
                        <li><Link to="/register">Register</Link></li>
                    </>
                )}
                <li><Link to="/about">About Us</Link></li>
                <li><Link to="/contact">Contact Us</Link></li>
                <li><Link to="/admin/login">Admin Login</Link></li>
        
            </ul>
        </nav>
    );
}

export default Navbar;
