import React from 'react';
import Navbar from './Navbar';
import './OrderPlacedPage.css';

const OrderPlacedPage = () => {
    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbar />
            <div className="order-placed-container">
                <h1>Order Placed Successfully</h1>
                <p>Thank you for your order! Your food will be delivered soon.</p>
            </div>
        </div>
    );
};

export default OrderPlacedPage;
