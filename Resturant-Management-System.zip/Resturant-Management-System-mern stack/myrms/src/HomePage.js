import React from 'react';
import Navbar from './Navbar';
import './HomePage.css'; 

function HomePage() {
    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbar />
            <section id="home">
                    <h2><b>Welcome to our Restaurant!</b></h2>
            </section>
        </div>
    );
}

export default HomePage;
