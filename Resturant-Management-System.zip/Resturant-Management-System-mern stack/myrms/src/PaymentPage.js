import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar';
import './PaymentPage.css';

const PaymentPage = ({ userId }) => {
    const [paymentMethod, setPaymentMethod] = useState('');
    const [upiId, setUpiId] = useState('');
    const [cardNumber, setCardNumber] = useState('');
    const [totalPrice, setTotalPrice] = useState(0);
    const navigate = useNavigate();

    useEffect(() => {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        const total = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);
        setTotalPrice(total);
    }, []);

    const handleProcessPayment = async () => {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];

        const orderDetails = {
            userId,
            items: cart,
            totalPrice,
            paymentMethod,
            ...(paymentMethod === 'UPI' && { upiId }),
            ...(paymentMethod === 'Card' && { cardNumber })
        };

        try {
            const response = await axios.post('http://localhost:5000/process-payment', orderDetails);
            if (response.status === 201) {
                localStorage.removeItem('cart');
                navigate('/orderplaced');
            } else {
                alert('Failed to place order');
            }
        } catch (error) {
            console.error('Error processing payment:', error);
            alert('Failed to place order');
        }
    };

    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbar />
            <div className="payment-container">
                <h2>Process Payment</h2>
                <div>
                    <p>Total Amount to Pay: ₹{totalPrice}</p>
                </div>
                <div>
                    <label>
                        <input
                            type="radio"
                            value="UPI"
                            checked={paymentMethod === 'UPI'}
                            onChange={(e) => setPaymentMethod(e.target.value)}
                        />
                        UPI
                    </label>
                    <label>
                        <input
                            type="radio"
                            value="Card"
                            checked={paymentMethod === 'Card'}
                            onChange={(e) => setPaymentMethod(e.target.value)}
                        />
                        Card
                    </label>
                    <label>
                        <input
                            type="radio"
                            value="COD"
                            checked={paymentMethod === 'COD'}
                            onChange={(e) => setPaymentMethod(e.target.value)}
                        />
                        Cash on Delivery
                    </label>
                </div>

                {paymentMethod === 'UPI' && (
                    <div>
                        <input
                            type="text"
                            placeholder="UPI ID"
                            value={upiId}
                            onChange={(e) => setUpiId(e.target.value)}
                        />
                    </div>
                )}
                {paymentMethod === 'Card' && (
                    <div>
                        <input
                            type="text"
                            placeholder="Card Number"
                            value={cardNumber}
                            onChange={(e) => setCardNumber(e.target.value)}
                        />
                    </div>
                )}

                <button onClick={handleProcessPayment}>Proceed</button>
            </div>
        </div>
    );
};

export default PaymentPage;
