// backend/db.js

// const mongoose = require('mongoose');

// const connectDB = async () => {
//     try {
//         await mongoose.connect('mongodb://localhost:27017/mydatabase', {
//             useNewUrlParser: true,
//             useUnifiedTopology: true
//         });
//         console.log('Connected to MongoDB');
//     } catch (err) {
//         console.error('Could not connect to MongoDB', err);
//     }
// };

// module.exports = connectDB;

// backend/db.js

// const mongoose = require('mongoose');

// const connectDB = async () => {
//     try {
//         await mongoose.connect('mongodb+srv://irfanmohamed03:eReD4G9at9zbSK8Z@cluster0.ghsofqj.mongodb.net/mydatabase?retryWrites=true&w=majority', {
//             useNewUrlParser: true,
//             useUnifiedTopology: true
//         });
//         console.log('Connected to MongoDB');
//     } catch (err) {
//         console.error('Could not connect to MongoDB', err);
//     }
// };

// module.exports = connectDB;


// db.js

// const mongoose = require('mongoose');

// const connectDB = async () => {
//     try {
//         await mongoose.connect('mongodb+srv://irfanmohamed03:eReD4G9at9zbSK8Z@cluster0.ghsofqj.mongodb.net/mydatabase?retryWrites=true&w=majority', {
//             useNewUrlParser: true,
//             useUnifiedTopology: true
//         });
//         console.log('Connected to MongoDB');
//     } catch (err) {
//         console.error('Could not connect to MongoDB', err);
//         process.exit(1); // Exit process with failure
//     }
// };

// module.exports = connectDB;



// backend/db.js

// db.js

// const mongoose = require('mongoose');

// const connectDB = async () => {
//     try {
//         await mongoose.connect('mongodb+srv://irfanmohamed03:eReD4G9at9zbSK8Z@cluster0.ghsofqj.mongodb.net/mydatabase?retryWrites=true&w=majority', {
//             useNewUrlParser: true,
//             useUnifiedTopology: true
//         });
//         console.log('Connected to MongoDB');
//     } catch (error) {
//         console.error('MongoDB connection error:', error);
//         process.exit(1);
//     }
// };

// module.exports = connectDB;

const mongoose=require('mongoose');
mongoose.connect('mongodb+srv://irfanmohamed03:eReD4G9at9zbSK8Z@cluster0.ghsofqj.mongodb.net/mydatabase?retryWrites=true&w=majority')
