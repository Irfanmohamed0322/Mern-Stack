import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar';
import './AddToCart.css';

function AddToCart() {
    const [cart, setCart] = useState([]);
    const [totalAmount, setTotalAmount] = useState(0);
    const navigate = useNavigate();

    useEffect(() => {
        const storedCart = JSON.parse(localStorage.getItem('cart')) || [];
        setCart(storedCart);
        calculateTotalAmount(storedCart);
    }, []);

    const calculateTotalAmount = (cartItems) => {
        let total = 0;
        cartItems.forEach(item => {
            total += item.price * item.quantity;
        });
        setTotalAmount(total);
    };

    const handleCheckout = () => {
        navigate('/delivery-address');
    };

    const incrementQuantity = (itemIndex) => {
        const updatedCart = [...cart];
        updatedCart[itemIndex].quantity++;
        setCart(updatedCart);
        localStorage.setItem('cart', JSON.stringify(updatedCart));
        calculateTotalAmount(updatedCart);
    };

    const decrementQuantity = (itemIndex) => {
        const updatedCart = [...cart];
        if (updatedCart[itemIndex].quantity === 1) {
            updatedCart.splice(itemIndex, 1);
        } else {
            updatedCart[itemIndex].quantity--;
        }
        setCart(updatedCart);
        localStorage.setItem('cart', JSON.stringify(updatedCart));
        calculateTotalAmount(updatedCart);
    };

    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbar />
            <div className="cart-container">
                <h2>Your Cart</h2>
                {cart.length === 0 ? (
                    <p>Your cart is empty</p>
                ) : (
                    <div>
                        {cart.map((item, index) => (
                            <div key={index} className="cart-item">
                                <div className="cart-item-info">
                                    <p><strong>{item.name}</strong></p>
                                    <p>Price: Rs.{item.price}</p>
                                    <div className="quantity-control">
                                        <button onClick={() => incrementQuantity(index)}>Add</button>
                                        <span>{item.quantity}</span>
                                        <button onClick={() => decrementQuantity(index)}>Remove</button>
                                    </div>
                                </div>
                            </div>
                        ))}
                        <div className="total-amount">Total Amount: Rs.{totalAmount}</div>
                        <button onClick={handleCheckout}>Checkout</button>
                    </div>
                )}
            </div>
        </div>
    );
}

export default AddToCart;
