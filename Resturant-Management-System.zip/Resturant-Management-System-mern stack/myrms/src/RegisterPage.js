import React, { useState } from 'react';
import axios from 'axios';
import Navbar from './Navbar'; 
import './RegisterPage.css'; 

function RegisterPage() {
    const [username, setUsername] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleRegister = async (e) => {
        e.preventDefault();

        try {
            const response = await axios.post('http://localhost:5000/api/register', { username, email, password });
            setMessage(response.data.message);
        } catch (error) {
            console.error('Error registering user:', error);
            setMessage('Registration failed');
        }
    };

    return (
              <div>
                  <header>
                      <h1>Restaurant Management System</h1>
                  </header>
                  <Navbar />
                  <div className="content">
                      <h1>Register</h1>
                      <form onSubmit={handleRegister}>
                          <div>
                              <label htmlFor="username">Username:</label>
                              <input type="text" id="username" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} required />
                          </div>
                          <div>
                              <label htmlFor="email">Email:</label>
                              <input type="email" id="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
                          </div>
                          <div>
                              <label htmlFor="password">Password:</label>
                              <input type="password" id="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                          </div>
                          <button type="submit">Register</button>
                      </form>
                      <p>Already have an account? <a href="/login">Login here</a>.</p>
                      {message && <p>{message}</p>}
                  </div>
              </div>
          );
      }

export default RegisterPage;
