// App.js

import React from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import HomePage from './HomePage';
import LoginPage from './LoginPage';
import RegisterPage from './RegisterPage';
import MenuPage from './MenuPage';
import OrderPage from './OrderPage';
import PaymentPage from './PaymentPage';
import AboutUsPage from './AboutUsPage';
import ContactUsPage from './ContactUsPage';
import AdminLoginPage from './AdminLoginPage';
import AddToCart from './AddToCart';
import OrderPlacedPage from './OrderPlacedPage';
import AdminDashboardPage from './AdminDashboardPage';
import OrdersPage from './OrdersPage';
import DeliveryAddressPage from './DeliveryAddressPage';
import AdminDeliveryAddressesPage from './AdminDeliveryAddressesPage'; 

function App() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const isAdminLoggedIn = localStorage.getItem('adminLoggedIn') === 'true';

    return (
        <Router>
            <Routes>
                <Route exact path="/" element={<HomePage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/register" element={<RegisterPage />} />
                <Route path="/menu" element={<MenuPage />} />
                <Route path="/order" element={isLoggedIn ? <OrderPage /> : <Navigate to="/login" />} />
                <Route path="/payment" element={isLoggedIn ? <PaymentPage /> : <Navigate to="/login" />} />
                <Route path="/about" element={<AboutUsPage />} />
                <Route path="/contact" element={<ContactUsPage />} />
                <Route path="/admin/login" element={<AdminLoginPage />} />
                <Route path="/cart" element={isLoggedIn ? <AddToCart /> : <Navigate to="/login" />} />
                <Route path="/orderplaced" element={<OrderPlacedPage />} />
                <Route path="/admin/dashboard" element={isAdminLoggedIn ? <AdminDashboardPage /> : <Navigate to="/admin/login" />} />
                <Route path="/admin/orders" element={isAdminLoggedIn ? <OrdersPage /> : <Navigate to="/admin/login" />} />
                <Route path="/delivery-address" element={isLoggedIn ? <DeliveryAddressPage /> : <Navigate to="/login" />} />
                <Route path="/admin/delivery-addresses" element={isAdminLoggedIn ? <AdminDeliveryAddressesPage /> : <Navigate to="/admin/login" />} />
            </Routes>
        </Router>
    );
}

export default App;
