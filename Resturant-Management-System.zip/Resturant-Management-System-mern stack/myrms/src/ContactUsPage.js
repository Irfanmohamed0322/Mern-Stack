import React from 'react';
import Navbar from './Navbar';

function ContactUsPage() {
    return (
        <div>
            <header>
                <h1>Restaurant Management System</h1>
            </header>
            <Navbar />
            <div className="content">
                <h1>Contact Us</h1>
                <form>
                    <div>
                        <label htmlFor="name">Name:</label>
                        <input type="text" id="name" name="name" required />
                    </div>
                    <div>
                        <label htmlFor="email">Email:</label>
                        <input type="email" id="email" name="email" required />
                    </div>
                    <div>
                        <label htmlFor="message">Message:</label>
                        <textarea id="message" name="message" rows="4" required></textarea>
                    </div>
                    <button type="submit">Submit</button>
                </form>
                <div>
                    <h2>Contact Information</h2>
                    <p>Phone: 123-456-7890</p>
                    <p>Email: resturant1@gamil.com</p>
                    <p>Address: 123 Main Street,Salem,India</p>
                </div>
            </div>
        </div>
    );
}

export default ContactUsPage;
